#pragma once

void showControlScreen();

void printHeading(char* header, char frameChar, int borderWidth);

void printHeadingMain(char* header);

void printHeadingSub(char* header);
