#pragma once
#include <stdbool.h>

int sudokuCheck (int Sudoku[9][9]);
bool sudokuFinished (int Sudoku[9][9]);

