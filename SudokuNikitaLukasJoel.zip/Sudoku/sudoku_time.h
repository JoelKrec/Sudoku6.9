#pragma once

double getCurrentSudokuTimeInSecs(clock_t startTime);
