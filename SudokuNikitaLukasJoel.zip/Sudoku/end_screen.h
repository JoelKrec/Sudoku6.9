#pragma once
#include <stdbool.h>
#include <time.h>

void showEndScreen(int timeInSecs);
